/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.controladores;

import cliente.controladores.ControladorCallBackInt;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import servidor.DTO.ClienteDTO;
import servidor.DTO.SubastaDTO;

/**
 *
 * @author TOSHIBA
 */
public class ControladorGestionClientesCallBackImpl extends UnicastRemoteObject implements ControladorGestionClientesCallBackInt {
    private final LinkedList<ControladorCallBackInt> listaReferencias;
    
    public ControladorGestionClientesCallBackImpl() throws RemoteException{
        super();
        this.listaReferencias = new LinkedList();
    }
    
    @Override
    public boolean registrarReferenciaRemota(ControladorCallBackInt referencia) throws RemoteException {
        return this.listaReferencias.add(referencia);
    }
    
    public void notificarClientes(SubastaDTO ObjSubasta){
        this.listaReferencias.forEach(
                obj->{
            try{
                obj.notificarCierreSubasta(ObjSubasta);
            }catch(RemoteException ex){
                System.out.println("Error al notificar al cliente");
            }            
        }
        );
    }
}
