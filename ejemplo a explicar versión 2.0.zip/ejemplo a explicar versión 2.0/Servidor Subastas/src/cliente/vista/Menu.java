/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cliente.vista;

import java.rmi.RemoteException;
import servidor.DTO.ClienteDTO;
import servidor.controladores.ControladorGestionClienteInt;
import servidor.utilidades.UtilidadesConsola;

/**
 *
 * @author TOSHIBA
 */
public class Menu {
    private final ControladorGestionClienteInt objRemotoCli;
    
    public Menu(ControladorGestionClienteInt objRemotoCli){
        this.objRemotoCli = objRemotoCli;
    }
    
    public void ejecutarMenu(){
        int opcion=0;
        do{
            System.out.println("==Menu==");
            System.out.println("1. Consultar usuario");			
            System.out.println("2. Salir");
            
            opcion = UtilidadesConsola.leerEntero();
            switch(opcion){
                case 1:
                    opcion1();
                    break;
                case 2:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Digite una opcion valida");
            }
        }while(opcion!=2);
    }
    
    private void opcion1(){
        try
        {
            System.out.println("Digite el login del cliente:");
            String login = UtilidadesConsola.leerCadena();
            ClienteDTO cliente = objRemotoCli.informacionUsuario(login);
            if(cliente.getNombres().equals("vacio") ){
                System.out.println("NO existe el cliente buscado...");
            }
            else{
                System.out.println("Informacion cliente:");
                System.out.println(cliente.toString());
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
}
