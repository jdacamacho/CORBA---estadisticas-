/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package servidor.controladores;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;
import sop_corba.ObtenerEstadisticasIntPackage.estadisticasDTO;


/**
 *
 * @author TOSHIBA
 */
public interface ControladorGestionProductoInt extends Remote{
    public ProductoDTO consultarProducto(String nombreProductoDTO) throws RemoteException;
    public List<ProductoDTO> listarProductos() throws RemoteException;
    public SubastaDTO consultarProductoSubastando() throws RemoteException;
    public boolean ofertar(SubastaDTO subasta) throws RemoteException;
    public estadisticasDTO consultarEstadisticas() throws RemoteException;
    public String consultarUltimas5Ofertas() throws RemoteException;
}
