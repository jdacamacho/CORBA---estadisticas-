package cliente.vista;

import cliente.utilidades.UtilidadesConsola;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.AdministradorDTO;
import servidor.DTO.LoginDTO;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;
import servidor.controladores.ControladorGestionAdministradorInt;
import servidor.controladores.ControladorGestionProductoInt;

public class Menu {
    
    private final ControladorGestionAdministradorInt objRemotoAdm;
    private final ControladorGestionProductoInt objRemotoPro;
    
    public Menu(ControladorGestionAdministradorInt objRemotoAdm, ControladorGestionProductoInt objRemotoPro)
    {
        this.objRemotoAdm=objRemotoAdm;
        this.objRemotoPro=objRemotoPro;
    }
    
    public void ejecutarMenuPrincipal()
    {
        int opcion = 0;
        int opcion2 = 0;
        String login ;
        do
        {
            System.out.println("==Menu==");
            System.out.println("1. Registrar usuario");			
            System.out.println("2. Iniciar sesion");
            System.out.println("3. Salir");

            opcion = UtilidadesConsola.leerEntero();

            switch(opcion)
            {
                case 1:
                    Opcion1();
                    break;	
                case 2:
                    System.out.println("Ingrese el login");
                    login = UtilidadesConsola.leerCadena();
                    System.out.println("Ingrese la contraseña");
                    String contraseña = UtilidadesConsola.leerCadena();
                    Boolean banderaSesion = Opcion2(login,contraseña);
                    AdministradorDTO administrador = informacionUsuarios(login);
                    System.out.println("Informacion Administrador:");
                    System.out.println(administrador.toString());
                    if(banderaSesion){
                        do
                        {
                            System.out.println("Bienvenido al sistema");
                            System.out.println("==Menu==");
                            System.out.println("1. Registrar producto");			
                            System.out.println("2. Listar productos");
                            System.out.println("3. abrir subaste");
                            System.out.println("4. cerrar subasta");
                            System.out.println("5. salir");

                            opcion2 = UtilidadesConsola.leerEntero();
                            switch(opcion2)
                            {
                                case 1:
                                    OpcionProducto1();
                                break;
                                case 2:
                                    OpcionProducto2();
                                break;
                                case 3:
                                    OpcionProducto3();
                                break;
                                case 4:
                                    OpcionProducto4();
                                break;
                                case 5:
                                    System.out.println("Salir...");
                                break;
                                default:
                                    System.out.println("Opción incorrecta");
                            }
                        }while(opcion2 != 5);

                    }
                    break;
                case 3:
                    System.out.println("Salir...");
                    break;
                default:
                    System.out.println("Opción incorrecta");
            }

        }while(opcion != 3);
    }

    private void Opcion1() 
    {
        try
        {
            System.out.println("==Registro del Administrador==");
            System.out.println("Ingrese el tipo de identificacion");
            String tipoIdentificacion = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese el numero de identificacion");
            String numeroIdentificacion = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese los nombres ");
            String nombres = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese los apellidos ");
            String apellidos = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese el login");
            String login = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese la contraseña");
            String contraseña = UtilidadesConsola.leerCadena();
            AdministradorDTO objUsuario = new AdministradorDTO(tipoIdentificacion,numeroIdentificacion,nombres,apellidos,login,contraseña);
            boolean bandera = objRemotoAdm.registrarAdministrador(objUsuario);
            if(bandera)
                    System.out.println("Registro realizado satisfactoriamente...");
            else
                    System.out.println("no se pudo realizar el registro...");
        }
        catch(RemoteException e)
        {
            System.out.println("La operacion no se pudo completar, intente nuevamente...");
        }
    }

    private boolean Opcion2(String login,String contraseña)
    {	
        try
        {
            LoginDTO objLogin = new LoginDTO(login,contraseña);
            boolean bandera = objRemotoAdm.iniciarSesion(objLogin);
            if(bandera){
                System.out.println("Inicio de sesion exitoso");
            }
            else{
                System.out.println("Login o contraseña no validos");
            }
            return bandera;
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
        return false;
    }
    
    private void OpcionProducto1() 
    {
        try
        {
            System.out.println("==Registro del Producto==");
            System.out.println("Ingrese el codigo");
            String codigo = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese el nombre");
            String nombre = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese el valor ");
            float valor = UtilidadesConsola.leerReal();
            
            ProductoDTO objProducto = new ProductoDTO(codigo,nombre,valor);
            boolean bandera = objRemotoPro.registrarProducto(objProducto);
            if(bandera)
                System.out.println("Registro realizado satisfactoriamente...");
            else
                System.out.println("no se pudo realizar el registro...");
        }
        catch(RemoteException e)
        {
            System.out.println("La operacion no se pudo completar, intente nuevamente...");
        }
    }
    
    private void OpcionProducto2() 
    {
        try
        {
            List<ProductoDTO> productos  = objRemotoPro.listarProductos();
            if(productos.size() == 0){
                System.out.println("No existen productos registrados en el sistema");
            }
            else{
                for(int i = 0 ; i<productos.size() ; i++){
                    System.out.println(productos.get(i).toString());
                }
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private void OpcionProducto3() 
    {
        try
        {
            System.out.println("Ingrese el codigo");
            String codigo = UtilidadesConsola.leerCadena();
            boolean bandera = objRemotoPro.abrirSubasta(codigo);
            if(bandera){
                System.out.println("Producto subastado con exito");
            }
            else{
                System.out.println("NO se pudo subastar el producto");
            }
            
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private void OpcionProducto4() 
    {
        try
        {
            SubastaDTO subasta = objRemotoPro.cerrarSubasta("vacio");
            if(subasta.getProducto().getCodigo().equals("-1")){
                System.out.println("No existe una subasta");
            }
            else{
                System.out.println("Subasta cerrada");
                if(subasta.getCliente().getNombres().equals("vacio")){
                    System.out.println("Nadie realizo una puja.");
                }
                else{
                    System.out.println("Subasta ganadora");
                    System.out.println("Nombre del ganador: " + subasta.getCliente().getNombres());
                    System.out.println("Apellido del ganador: " + subasta.getCliente().getApellidos());
                    System.out.println("Nombre del producto: " + subasta.getProducto().getNombre() );
                    System.out.println("Valor real del producto: " + subasta.getProducto().getValor());
                    System.out.println("Valor con el que se gano:" + subasta.getPuja());
                }
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private AdministradorDTO informacionUsuarios(String login){
        AdministradorDTO administrador = new AdministradorDTO("vacio","-1","vacio","vacio","vacio","vacio"); 
        try
        {
            administrador = objRemotoAdm.informacionUsuario(login);
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
        return administrador;
    }
}
