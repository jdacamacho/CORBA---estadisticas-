/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cliente.controladores;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import servidor.DTO.ClienteDTO;
import servidor.DTO.SubastaDTO;
import servidor.controladores.ControladorGestionClientesCallBackInt;

/**
 *
 * @author TOSHIBA
 */
public class ControladorCallBackImpl extends UnicastRemoteObject implements ControladorCallBackInt{
    public ControladorCallBackImpl() throws RemoteException{
        super();
    }
    
    @Override
    public void notificarCierreSubasta(SubastaDTO subasta) throws RemoteException {
        if(subasta.getCliente().getNombres().equals("vacio")){
            System.out.println("Nombre del producto: " + subasta.getProducto().getNombre() );
            System.out.println("Valor real del producto: " + subasta.getProducto().getValor());
            System.out.println("Se cerro la subasta sin ganadores, nadie pujo por el producto");
        }
        else{
            System.out.println("Subasta ganadora");
            System.out.println("Nombre del ganador: " + subasta.getCliente().getNombres());
            System.out.println("Apellido del ganador: " + subasta.getCliente().getApellidos());
            System.out.println("Correo del ganador: " + subasta.getCliente().getCorreo());
            System.out.println("Telefono del ganador: " + subasta.getCliente().getTelefono());
            System.out.println("Nombre del producto: " + subasta.getProducto().getNombre() );
            System.out.println("Valor real del producto: " + subasta.getProducto().getValor());
            System.out.println("Valor con el que se gano:" + subasta.getPuja());
        }
    }
}
