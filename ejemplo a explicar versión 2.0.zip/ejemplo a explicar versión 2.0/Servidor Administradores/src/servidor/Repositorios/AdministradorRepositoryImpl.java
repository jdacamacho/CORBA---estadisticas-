/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.Repositorios;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.AdministradorDTO;

/**
 *
 * @author INGESIS
 */
public class AdministradorRepositoryImpl implements AdministradorRepositoryInt{
    
    private final ArrayList<AdministradorDTO> misUsuarios;
    
    public AdministradorRepositoryImpl()
    {        
        this.misUsuarios = new ArrayList();
        AdministradorDTO a1 = new AdministradorDTO("cedula","1003","simon","guzman","siguzman","123");
        this.misUsuarios.add(a1);
    }
    
    @Override
    public boolean registrarAdministrador(AdministradorDTO objUsuario) {
       System.out.println("Entrando a registrar");
        boolean bandera=false;
        
        if(this.misUsuarios.size() < 5)
        {            
            System.out.println("Administrador registrado");
            bandera=this.misUsuarios.add(objUsuario);
        }
        else{
            System.out.println("Error al registrar el administrador");
        }
        return bandera;
    }

    @Override
    public List<AdministradorDTO> listarAdministrador() {
        System.out.println("Entrando a listar administradores");
        return this.misUsuarios;
    }

    @Override
    public boolean iniciarSesion(LoginDTO objLogin) {
        System.out.println("Entrando a Iniciar sesion");
        for(int i = 0 ;i<misUsuarios.size();i++){
            if(misUsuarios.get(i).getLogin().equals(objLogin.getLogin())){
                if(misUsuarios.get(i).getContraseña().equals(objLogin.getContraseña())){
                    System.out.println("Iniciando sesion");
                    return true;
                }
            }
        }
        System.out.println("Inicio de sesion no valido...");
        return false;
    }

    @Override
    public AdministradorDTO informacionUsuario(String login) {
        System.out.println("Entrando a informacion administrador");
        for(int i = 0; i<misUsuarios.size(); i++){
            if(misUsuarios.get(i).getLogin().equals(login)){
                System.out.println("Enviando informacion del administrador");
                return misUsuarios.get(i);
            }
        }
        System.out.println("No se encontro la informacion del administrador");
        AdministradorDTO usuarioNoEncontrado = new AdministradorDTO("vacio","-1","vacio","vacio","vacio","vacio");
        return usuarioNoEncontrado;
    }
}
