/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor.servicios;


import cliente.utilidades.UtilidadesRegistroC;
import cliente.vista.Menu;
import java.rmi.Remote;
import servidor.utilidades.UtilidadesRegistroS;
import servidor.utilidades.UtilidadesConsola;
import java.rmi.RemoteException;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import servidor.Repositorios.ProductoRepositoryImpl;
import servidor.controladores.ControladorGestionClienteInt;
import servidor.controladores.ControladorGestionClientesCallBackImpl;
import servidor.controladores.ControladorGestionProductoImpl;
import sop_corba.ObtenerEstadisticasInt;
import sop_corba.ObtenerEstadisticasIntHelper;

public class ServidorDeObjetos
{
    
    private static ControladorGestionClienteInt objRemotoCliente;
    
    public static void main(String args[]) throws RemoteException, InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName
    {        
         
        int numPuertoRMIRegistry = 2020;
        int numPuertoRMIRegistryCliente=2022;
        String direccionIpRMIRegistry = "localhost";
                       
        /*System.out.println("Cual es el la dirección ip donde se encuentra  el rmiRegistry ");
        direccionIpRMIRegistry = UtilidadesConsola.leerCadena();
        System.out.println("Cual es el número de puerto por el cual escucha el rmiRegistry ");
        numPuertoRMIRegistry = UtilidadesConsola.leerEntero(); 
        System.out.println("Cual es el número de puerto por el cual escucha el rmiRegistry cliente ");
        numPuertoRMIRegistryCliente = UtilidadesConsola.leerEntero(); */
        
        //corba
        ObtenerEstadisticasInt ref;
        String[] vec = new String[4];
        vec[0] = "-ORBInitialPort";
        vec[1] = "localhost";
        vec[2] = "-ORBInitialPort";
        vec[3] = "2024";
        ORB orb = ORB.init(vec, null);
        org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
        NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
        String name = "objUsuarios";
        ref = ObtenerEstadisticasIntHelper.narrow(ncRef.resolve_str(name));
        System.out.println("Obtenido el manejador sobre el servidor de objetos: " + ref);
        
        
        ProductoRepositoryImpl objRepository = new ProductoRepositoryImpl(ref);
        ControladorGestionClientesCallBackImpl objRemotoClientes = new ControladorGestionClientesCallBackImpl();
        ControladorGestionProductoImpl objRemoto = new ControladorGestionProductoImpl(objRepository,objRemotoClientes);//se leasigna el puerto de escucha del objeto remoto
        
        try
        {
           UtilidadesRegistroS.arrancarNS(numPuertoRMIRegistry);
           UtilidadesRegistroS.RegistrarObjetoRemoto((Remote)objRemoto, direccionIpRMIRegistry, numPuertoRMIRegistry, "objServicioGestionProductos");
           UtilidadesRegistroS.RegistrarObjetoRemoto((Remote)objRemotoClientes, direccionIpRMIRegistry, numPuertoRMIRegistry, "objServicioCallBack");            
           objRemotoCliente = (ControladorGestionClienteInt) UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry,numPuertoRMIRegistryCliente, "objServicioGestionClientes");
            Menu objMenu= new Menu(objRemotoCliente);
            objMenu.ejecutarMenu();
        
        } catch (Exception e)
        {
            System.err.println("No fue posible Arrancar el NS o Registrar el objeto remoto" +  e.getMessage());
        }
        
        
    }
}
