/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.Repositorios;

import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.ClienteDTO;

/**
 *
 * @author INGESIS
 */
public interface ClienteRepositoryInt {
    public boolean registrarCliente(ClienteDTO objUsuario);
    public boolean iniciarSesion(LoginDTO objLogin) ;
    public List<ClienteDTO> listarCliente();
    public ClienteDTO informacionUsuario(String login);
}
