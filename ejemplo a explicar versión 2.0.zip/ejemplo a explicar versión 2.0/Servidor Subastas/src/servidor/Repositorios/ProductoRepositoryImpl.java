/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.Repositorios;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import servidor.DTO.ClienteDTO;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;
import sop_corba.ObtenerEstadisticasInt;
import sop_corba.ObtenerEstadisticasIntHelper;
import sop_corba.ObtenerEstadisticasIntPackage.estadisticasDTO;
import sop_corba.ObtenerEstadisticasIntPackage.estadisticasDTOHolder;
/**
 *
 * @author TOSHIBA
 */
public class ProductoRepositoryImpl implements ProductoRepositoryInt{
    
    private final ObtenerEstadisticasInt ref;
    private final ArrayList<ProductoDTO> misProductos;
    private SubastaDTO actualSubasta;
    
    public ProductoRepositoryImpl(ObtenerEstadisticasInt ref) throws InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName
    {        
        this.misProductos = new ArrayList();
        ProductoDTO productoEnSubasta = new ProductoDTO("-1","vacio",0);
        ClienteDTO clienteSubasta = new ClienteDTO("vacio","-1","vacio","vacio","vacio","vacio","vacio","vacio");
        this.actualSubasta = new SubastaDTO(clienteSubasta,productoEnSubasta,0);
        this.ref = ref;
        
        ProductoDTO p1 = new ProductoDTO("1002","papas",2550);
        ProductoDTO p2 = new ProductoDTO("1003","helado",2500);
        this.misProductos.add(p1);
        this.misProductos.add(p2);
    }
    
    @Override
    public boolean registrarProducto(ProductoDTO objProducto)  {
        System.out.println("Entrando a registrar producto");
        boolean bandera=false;
        
        if(this.misProductos.size() < 5)
        {       
            System.out.println("Producto registrado");
            bandera=this.misProductos.add(objProducto);
        }
        else{
            System.out.println("Error al registrar el producto");
        }
        return bandera;
    }

    @Override
    public List<ProductoDTO> listarProductos(){
        System.out.println("Entrando a listar productos");
        return this.misProductos;
    }

    @Override
    public boolean abrirSubasta(String codigo){
        System.out.println("Entrando a abrir subasta");
        if(this.actualSubasta.getProducto().getCodigo().equals("-1")){
            for(int i = 0 ; i<this.misProductos.size() ; i++){
                if(this.misProductos.get(i).getCodigo().equals(codigo)){
                    System.out.println("Producto subastado");
                    this.actualSubasta.setProducto(this.misProductos.get(i));
                    this.actualSubasta.setPuja(this.misProductos.get(i).getValor());
                    return true;
                }
            }
        }
        System.out.println("NO se pudo abrir la subasta");
        return false;
    }

    @Override
    public SubastaDTO cerrarSubasta(String codigo){
        System.out.println("Entrando a cerrar subasta");
        SubastaDTO subastaGanadora = this.actualSubasta;
        if(this.actualSubasta.getProducto().getCodigo().equals("-1") ){
            System.out.println("NO existe una subasta para ser cerrada.");
        }
        else{
            System.out.println("Subasta cerrada");
            subastaGanadora = this.actualSubasta;
            ProductoDTO productoEnSubasta = new ProductoDTO("-1","vacio",0);
            ClienteDTO clienteSubasta = new ClienteDTO("vacio","-1","vacio","vacio","vacio","vacio","vacio","vacio");
            this.actualSubasta = new SubastaDTO(clienteSubasta,productoEnSubasta,0);
            ref.eliminarOfertas();
        }
        return subastaGanadora;
    }

    @Override
    public ProductoDTO consultarProducto(String nombreProductoDTO) throws RemoteException {
        System.out.println("Entrando a consultar producto");
        ProductoDTO productoNoEncontrado = new ProductoDTO("-1","vacio",0);
        for(int i = 0 ; i<this.misProductos.size() ; i++){
            if(this.misProductos.get(i).getNombre().equals(nombreProductoDTO)){
                System.out.println("Devolviendo producto encontrado");
                return this.misProductos.get(i);
            }
        }
        System.out.println("NO se encontro el producto");
        return productoNoEncontrado;
    }

    @Override
    public SubastaDTO consultarProductoSubastando() throws RemoteException {
        System.out.println("Entrando a consultar producto subastando");
        if(this.actualSubasta.getProducto().getCodigo().equals("-1")){
            System.out.println("NO existe una subasta actualmente");
        }
        else{
            System.out.println("Enviando informacion de la subasta actual");
        }
        return this.actualSubasta;
    }

    @Override
    public boolean ofertar(SubastaDTO subasta) throws RemoteException {
        System.out.println("Entrando a realizar oferta");
        if(this.actualSubasta.getProducto().getCodigo().equals("-1") == false ){
            if(subasta.getPuja() > this.actualSubasta.getPuja()){
                this.actualSubasta.setCliente(subasta.getCliente());
                this.actualSubasta.setPuja(subasta.getPuja());
                System.out.println("Oferta realizada con exito");
                ref.registrarValorOferta(actualSubasta.getPuja());
                return true;
            }
        }
        System.out.println("Oferta rechazada");
        return false;
    }
    
    @Override
    public estadisticasDTO consultarEstadisticas() throws RemoteException {
        estadisticasDTO estadisticasVacias = new estadisticasDTO(0,0,0,0);
        estadisticasDTOHolder objestadisticas = new estadisticasDTOHolder();
        ref.consultarEstadisticas(objestadisticas);
        if(objestadisticas.value.cantidadSolicitudes != 0 ){
            return objestadisticas.value;
        }
        else{
            System.out.println("no existe estadisticas...");
        }
        return estadisticasVacias;
    }
    
    @Override
    public String consultarUltimas5Ofertas() throws RemoteException {
        String ultimasOfertas = ref.obtenerOfertas();
        if(ultimasOfertas.equals(" ")){
            System.out.println("No existen aun ofertas...");
        }
        else{
            System.out.println("Devolviendo ofertas...");
        }
        return ultimasOfertas;
    }

    
    public SubastaDTO getActualSubasta() {
        return actualSubasta;
    }

    public void setActualSubasta(SubastaDTO actualSubasta) {
        this.actualSubasta = actualSubasta;
    }
}
