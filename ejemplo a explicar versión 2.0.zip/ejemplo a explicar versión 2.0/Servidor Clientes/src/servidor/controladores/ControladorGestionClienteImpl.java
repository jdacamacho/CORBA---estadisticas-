/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.controladores;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.ClienteDTO;
import servidor.Repositorios.ClienteRepositoryInt;

/**
 *
 * @author INGESIS
 */
public class ControladorGestionClienteImpl extends UnicastRemoteObject implements ControladorGestionClienteInt{
    
    private final ClienteRepositoryInt objUsuariosRepository;
    
    public ControladorGestionClienteImpl(ClienteRepositoryInt objUsuariosRepository) throws RemoteException{
        super();
        this.objUsuariosRepository = objUsuariosRepository;
    }
    
    @Override
    public boolean registrarCliente(ClienteDTO objUsuario) throws RemoteException {
        return this.objUsuariosRepository.registrarCliente(objUsuario);
    }

    @Override
    public List<ClienteDTO> listarCliente() throws RemoteException {
        return this.objUsuariosRepository.listarCliente();
    }

    @Override
    public boolean iniciarSesion(LoginDTO objLogin) throws RemoteException {
        return this.objUsuariosRepository.iniciarSesion(objLogin);
    }

    @Override
    public ClienteDTO informacionUsuario(String login) throws RemoteException {
        return this.objUsuariosRepository.informacionUsuario(login);
    }
    
}
